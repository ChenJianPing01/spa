/* 主模块 */

import { Shell } from './spa.shell.js';

class Spa {

    constructor($container) {
        this.shell = new Shell();        
        this.shell.initModule($container);
    }
}

const lc = new Spa($('#spa'));


