/* model模块 */

import { util } from './spa.util.js';
export { Model };

class Model {

    constructor() {
        ;
    }
}

